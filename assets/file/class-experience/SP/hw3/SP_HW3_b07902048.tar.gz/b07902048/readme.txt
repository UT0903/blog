將scheduler.o與scheduler.h放進資料夾
執行make指令

